"""
Attendance Management Module
Handles student attendance records.
"""

attendance_record = {}

def mark_present(student):
    """
    Mark student as present.

    Args:
        student (str): Student name.
    """
    attendance_record[student] = "Present"


def mark_absent(student):
    """
    Mark student as absent.

    Args:
        student (str): Student name.
    """
    attendance_record[student] = "Absent"


def get_attendance(student):
    """
    Get attendance status of a student.

    Args:
        student (str): Student name.

    Returns:
        str: Attendance status or 'No record found'.
    """
    return attendance_record.get(student, "No record found")
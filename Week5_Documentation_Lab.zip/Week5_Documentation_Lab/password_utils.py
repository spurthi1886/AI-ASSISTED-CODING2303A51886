"""
Password Utilities Module
Provides basic password validation functions.
"""

def check_strength(password):
    """
    Validate password strength.

    Args:
        password (str): The password string.

    Returns:
        bool: True if password length is at least 8 characters, else False.
    """
    return len(password) >= 8
"""
String Utilities Module
Provides utility functions for string manipulation.
"""

def reverse_string(text):
    """
    Reverse the input string.

    Args:
        text (str): The string to reverse.

    Returns:
        str: The reversed string.
    """
    return text[::-1]
"""
Math Utilities Module
Provides basic mathematical operations.
"""

def square(n):
    """
    Calculate square of a number.

    Args:
        n (int or float): Input number.

    Returns:
        int or float: Square of n.
    """
    return n * n


def cube(n):
    """
    Calculate cube of a number.

    Args:
        n (int or float): Input number.

    Returns:
        int or float: Cube of n.
    """
    return n * n * n


def factorial(n):
    """
    Compute factorial of a non-negative integer.

    Args:
        n (int): Non-negative integer.

    Returns:
        int: Factorial of n.

    Raises:
        ValueError: If n is negative.
    """
    if n < 0:
        raise ValueError("Factorial not defined for negative numbers")

    if n == 0 or n == 1:
        return 1

    result = 1
    for i in range(2, n + 1):
        result *= i

    return result
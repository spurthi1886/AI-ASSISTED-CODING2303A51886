from string_utils import reverse_string
from password_utils import check_strength
from math_utils import square, cube, factorial
from attendance import mark_present, get_attendance

print(reverse_string("Spurthi"))
print(check_strength("password123"))
print(square(4))
print(cube(3))
print(factorial(5))

mark_present("Spurthi")
print(get_attendance("Spurthi"))
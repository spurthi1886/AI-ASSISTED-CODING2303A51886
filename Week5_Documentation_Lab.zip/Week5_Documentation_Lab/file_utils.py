"""
File Utilities Module
Provides file handling operations.
"""

def read_file(filename):
    """
    Read content from a file.

    Args:
        filename (str): File path.

    Returns:
        str: File content.

    Raises:
        FileNotFoundError: If file is missing.
        IOError: If file cannot be accessed.
    """
    with open(filename, 'r') as f:
        return f.read()